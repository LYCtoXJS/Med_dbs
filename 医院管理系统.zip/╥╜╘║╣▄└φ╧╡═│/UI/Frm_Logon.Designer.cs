﻿
namespace UI
{
    partial class Frm_Logon
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Txt_UserName = new System.Windows.Forms.TextBox();
            this.Txt_Psd = new System.Windows.Forms.TextBox();
            this.Txt_Psd2 = new System.Windows.Forms.TextBox();
            this.Lbl_UserName = new System.Windows.Forms.Label();
            this.Lbl_Psd = new System.Windows.Forms.Label();
            this.Lbl_Psd2 = new System.Windows.Forms.Label();
            this.Btn_Logon = new System.Windows.Forms.Button();
            this.Btn_Return = new System.Windows.Forms.Button();
            this.Lbl_Id = new System.Windows.Forms.Label();
            this.Txt_Id = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // Txt_UserName
            // 
            this.Txt_UserName.Location = new System.Drawing.Point(356, 44);
            this.Txt_UserName.Name = "Txt_UserName";
            this.Txt_UserName.Size = new System.Drawing.Size(115, 25);
            this.Txt_UserName.TabIndex = 0;
            // 
            // Txt_Psd
            // 
            this.Txt_Psd.Location = new System.Drawing.Point(356, 158);
            this.Txt_Psd.Name = "Txt_Psd";
            this.Txt_Psd.PasswordChar = '*';
            this.Txt_Psd.Size = new System.Drawing.Size(115, 25);
            this.Txt_Psd.TabIndex = 1;
            // 
            // Txt_Psd2
            // 
            this.Txt_Psd2.Location = new System.Drawing.Point(356, 239);
            this.Txt_Psd2.Name = "Txt_Psd2";
            this.Txt_Psd2.Size = new System.Drawing.Size(115, 25);
            this.Txt_Psd2.TabIndex = 2;
            // 
            // Lbl_UserName
            // 
            this.Lbl_UserName.AutoSize = true;
            this.Lbl_UserName.Location = new System.Drawing.Point(283, 54);
            this.Lbl_UserName.Name = "Lbl_UserName";
            this.Lbl_UserName.Size = new System.Drawing.Size(67, 15);
            this.Lbl_UserName.TabIndex = 4;
            this.Lbl_UserName.Text = "用户名：";
            // 
            // Lbl_Psd
            // 
            this.Lbl_Psd.AutoSize = true;
            this.Lbl_Psd.Location = new System.Drawing.Point(296, 168);
            this.Lbl_Psd.Name = "Lbl_Psd";
            this.Lbl_Psd.Size = new System.Drawing.Size(52, 15);
            this.Lbl_Psd.TabIndex = 5;
            this.Lbl_Psd.Text = "密码：";
            this.Lbl_Psd.Click += new System.EventHandler(this.label2_Click);
            // 
            // Lbl_Psd2
            // 
            this.Lbl_Psd2.AutoSize = true;
            this.Lbl_Psd2.Location = new System.Drawing.Point(266, 248);
            this.Lbl_Psd2.Name = "Lbl_Psd2";
            this.Lbl_Psd2.Size = new System.Drawing.Size(82, 15);
            this.Lbl_Psd2.TabIndex = 6;
            this.Lbl_Psd2.Text = "确认密码：";
            // 
            // Btn_Logon
            // 
            this.Btn_Logon.Location = new System.Drawing.Point(280, 344);
            this.Btn_Logon.Name = "Btn_Logon";
            this.Btn_Logon.Size = new System.Drawing.Size(86, 32);
            this.Btn_Logon.TabIndex = 7;
            this.Btn_Logon.Text = "注册";
            this.Btn_Logon.UseVisualStyleBackColor = true;
            this.Btn_Logon.Click += new System.EventHandler(this.Btn_Logon_Click);
            // 
            // Btn_Return
            // 
            this.Btn_Return.Location = new System.Drawing.Point(457, 344);
            this.Btn_Return.Name = "Btn_Return";
            this.Btn_Return.Size = new System.Drawing.Size(81, 32);
            this.Btn_Return.TabIndex = 8;
            this.Btn_Return.Text = "返回登陆";
            this.Btn_Return.UseVisualStyleBackColor = true;
            this.Btn_Return.Click += new System.EventHandler(this.Btn_Return_Click);
            // 
            // Lbl_Id
            // 
            this.Lbl_Id.AutoSize = true;
            this.Lbl_Id.Location = new System.Drawing.Point(266, 121);
            this.Lbl_Id.Name = "Lbl_Id";
            this.Lbl_Id.Size = new System.Drawing.Size(82, 15);
            this.Lbl_Id.TabIndex = 9;
            this.Lbl_Id.Text = "身份证号：";
            this.Lbl_Id.Click += new System.EventHandler(this.label1_Click);
            // 
            // Txt_Id
            // 
            this.Txt_Id.Location = new System.Drawing.Point(358, 111);
            this.Txt_Id.Name = "Txt_Id";
            this.Txt_Id.Size = new System.Drawing.Size(113, 25);
            this.Txt_Id.TabIndex = 10;
            // 
            // Frm_Logon
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.Txt_Id);
            this.Controls.Add(this.Lbl_Id);
            this.Controls.Add(this.Btn_Return);
            this.Controls.Add(this.Btn_Logon);
            this.Controls.Add(this.Lbl_Psd2);
            this.Controls.Add(this.Lbl_Psd);
            this.Controls.Add(this.Lbl_UserName);
            this.Controls.Add(this.Txt_Psd2);
            this.Controls.Add(this.Txt_Psd);
            this.Controls.Add(this.Txt_UserName);
            this.Name = "Frm_Logon";
            this.Text = "注册";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox Txt_UserName;
        private System.Windows.Forms.TextBox Txt_Psd;
        private System.Windows.Forms.TextBox Txt_Psd2;
        private System.Windows.Forms.Label Lbl_UserName;
        private System.Windows.Forms.Label Lbl_Psd;
        private System.Windows.Forms.Label Lbl_Psd2;
        private System.Windows.Forms.Button Btn_Logon;
        private System.Windows.Forms.Button Btn_Return;
        private System.Windows.Forms.Label Lbl_Id;
        private System.Windows.Forms.TextBox Txt_Id;
    }
}