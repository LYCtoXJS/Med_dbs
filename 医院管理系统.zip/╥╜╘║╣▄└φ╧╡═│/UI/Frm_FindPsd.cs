﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace UI
{
    public partial class Frm_FindPsd : Form
    {
        public Frm_FindPsd()
        {
            InitializeComponent();
        }

        private void Frm_FindPsd_Load(object sender, EventArgs e)
        {

        }

        private void btn_FindPsd_Click(object sender, EventArgs e)
        {

        }

        private void btn_FindPsd_Click_1(object sender, EventArgs e)
        {
            SqlConnection sqlConnection = new SqlConnection();
            sqlConnection.ConnectionString =
                "Server=晚风;Database=DataPalpitation;Integrated Security=sspi";
            SqlCommand sqlCommand = new SqlCommand();
            sqlCommand.Connection = sqlConnection;
            sqlCommand.CommandText =
                "UPDATE tb_UserImfor" +
                 " SET Password=HASHBYTES('MD5',@Password)" +
                 " WHERE UserName=@UserName AND UserID=@UserID;";
            sqlCommand.Parameters.AddWithValue("@UserID", this.txt_Id.Text.Trim());
            sqlCommand.Parameters.AddWithValue("@UserName", this.txt_UserName.Text.Trim());
            sqlCommand.Parameters.AddWithValue("@Password", this.txt_Id.Text.Trim().Substring(14, 4));
            sqlConnection.Open();
            int rowAffected = sqlCommand.ExecuteNonQuery();
            sqlConnection.Close();
            if (rowAffected == 1)                                                                       //若成功写入1行记录；
            {
                MessageBox.Show("密码已改为身份证号后四位");															//给出正确提示；
            }
            else                                                                                        //否则；
            {
                MessageBox.Show("身份证号或用户名有误！");															//给出错误提示；
            }
        }
    }
}
