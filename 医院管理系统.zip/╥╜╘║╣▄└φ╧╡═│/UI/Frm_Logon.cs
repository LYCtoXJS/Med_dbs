﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace UI
{
    public partial class Frm_Logon : Form
    {
        public Frm_Logon()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void Btn_Logon_Click(object sender, EventArgs e)
        {
            if (this.Txt_UserName.Text.Trim() == "")                                                      //若用户号文本框为空；
            {
                MessageBox.Show("用户名不能为空！");														//给出错误提示；
                this.Txt_UserName.Focus();                                                                //用户号文本框获得焦点；
                return;                                                                                 //返回；
            }
            if (this.Txt_Psd.Text.Trim() == "")                                                    //若密码文本框为空；
            {
                MessageBox.Show("密码不能为空！");														//给出错误提示；
                this.Txt_Psd.Focus();                                                              //密码文本框获得焦点；
                return;                                                                                 //返回；
            }
            if (this.Txt_Psd2.Text.Trim()!=this.Txt_Psd.Text.Trim())                                                    
            {
                MessageBox.Show("两次密码输入不一致，请重新输入！");														//给出错误提示；
                this.Txt_Psd2.Focus();                                                                //用户号文本框获得焦点；
                return;                                                                                 //返回；
            }
            SqlConnection sqlConnection = new SqlConnection();                                          //声明并实例化SQL连接；
            sqlConnection.ConnectionString =
                "Server=晚风;Database=MedDataBase;Integrated Security=sspi";                         //在字符串变量中，描述连接字符串所需的服务器地址、数据库名称、集成安全性（即是否使用Windows验证）；
            SqlCommand sqlCommand = sqlConnection.CreateCommand();
            sqlCommand.CommandText =
                 "INSERT tb_User (UserName,Id,Password)  VALUES(@UserName,@Id,HASHBYTES('MD5',@Password)); ";              //指定SQL命令的命令文本；命令文本包含参数；
            sqlCommand.Parameters.AddWithValue("@UserName", this.Txt_UserName.Text.Trim());
            sqlCommand.Parameters.AddWithValue("@Password", this.Txt_Psd.Text.Trim());
            sqlCommand.Parameters.AddWithValue("@Id",this.Txt_Id.Text.Trim());
            sqlCommand.Parameters["@Password"].SqlDbType = SqlDbType.VarChar;
            sqlConnection.Open();                                                                       //打开SQL连接；
            int rowAffected = sqlCommand.ExecuteNonQuery();                                             //调用SQL命令的方法ExecuteNonQuery来执行命令，向数据库写入数据，并返回受影响行数；
            sqlConnection.Close();                                                                      //关闭SQL连接；
            if (rowAffected == 1)                                                                       //若成功写入1行记录；
            {
                MessageBox.Show("注册成功。");															//给出正确提示；
            }
            else                                                                                        //否则；
            {
                MessageBox.Show("注册失败！");															//给出错误提示；
            }
        }

        private void Btn_Return_Click(object sender, EventArgs e)
        {
            Frm_Login frm_Login = new Frm_Login();
            frm_Login.ShowDialog();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
