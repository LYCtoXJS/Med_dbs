﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace UI
{
    public partial class Frm_Login : Form
    {
        public Frm_Login()
        {
            InitializeComponent();
        }

        #region 窗体移动
      
        private bool IsMouseDownInForm = false;
        private Point p;


     

        private void Form1_MouseMove(object sender, MouseEventArgs e)
        {
            if (IsMouseDownInForm)
            {
                Left += e.Location.X - p.X;
                Top += e.Location.Y - p.Y;
            }
        }

        private void Form1_MouseDown(object sender, MouseEventArgs e)
        {
            IsMouseDownInForm = true;
            p = e.Location;
        }

        private void Form1_MouseUp(object sender, MouseEventArgs e)
        {
            IsMouseDownInForm = false;
        }
        #endregion


        
        private void log_Load(object sender, EventArgs e)
        {
        
        }

        private void txtUname_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void txtPwd_TextChanged(object sender, EventArgs e)
        {
           
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void toolTip1_Popup(object sender, PopupEventArgs e)
        {

        }

        private void Btn_Logon_Click(object sender, EventArgs e)
        {
            Frm_Logon frm_Logon = new Frm_Logon();
            frm_Logon.ShowDialog();
        }

        private void Btn_Login_Click(object sender, EventArgs e)
        {
            SqlConnection sqlConnection = new SqlConnection();                              //声明并实例化SQL连接；
            sqlConnection.ConnectionString =
               "Server=晚风;Database=MedDataBase;Integrated Security=sspi";             //在字符串变量中，描述连接字符串所需的服务器地址、数据库名称、集成安全性（即是否使用Windows验证）；
            SqlCommand sqlCommand = new SqlCommand();                                       //声明并实例化SQL命令；
            sqlCommand.Connection = sqlConnection;                                          //将SQL命令的属性Connection指向SQL连接；
            sqlCommand.CommandText =                                                        //指定SQL命令的命令文本；命令文本由字符串拼接而成；
                $"SELECT COUNT(1) FROM tb_User" +
                $" WHERE UserName='{this.txtUname.Text.Trim()}'" +								//将文本框的文本清除首尾的空格后，拼接至命令文本中；
                $" AND Password=HASHBYTES('MD5','{this.txtPwd.Text.Trim()}');";
            sqlConnection.Open();                                                           //打开SQL连接；
            int rowCount = (int)sqlCommand.ExecuteScalar();                                 //调用SQL命令的方法ExecuteScalar来执行命令，并接受单个结果（即标量）；
                                                                                            //执行标量的返回结果类型为object，可通过强制类型转换，转为整型；
            sqlConnection.Close();                                                          //关闭SQL连接；
            if (rowCount == 1)                                                              //若查得所输用户号相应的1行记录；
            {
                MessageBox.Show("登录成功。");												//给出正确提示；
            }
            else                                                                            //否则；
            {
                MessageBox.Show("用户号/密码有误，请重新输入！");								//给出错误提示；
                this.txtPwd.Focus();                                                  //密码文本框获得焦点；
                this.txtPwd.SelectAll();                                              //密码文本框内所有文本被选中；
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {
            Frm_FindPsd frm_FindPsd = new Frm_FindPsd();
            frm_FindPsd.ShowDialog();

        }
    }
}
